Üdv itt, 
Ez lesz a lényege az appnak:

2 része van frontend backend 

apiknak a randomoos fogjuk hasznalni.. hozok létre egy másik txt abba fogjuk irni ki mit csinál és az ötleteket illetve hol tartünk.

3. A testing oda kell majd tenni, ha vaalki tesztel valamit ott irja meg és a Buildbe töltse majd vissza, ne legyen bug

Lesz helper amiben berakok segitseget, ne kellen ai vagy keresés hozzá pl telepites react stb..


a lomtar lesz a főbe oda azok mennek ami tényleg shit lett és a testbe is raktam amiben ideglenesen van azért van igy viktor ne rageljen a nav miatt de oda tegyetek mindent a test lomtarba ami idegelenes a vegso shitcode az a fobee


Ha valaki dolgotott irjona messange.txt mi volt az mit csinalt hogy tudjuka  vegso ellenorzes utanirjuk a peddingbe.

Ennyi,


Frontend backend előtelepitve lesz és a css is elővan bekotve csak fejlesztés kell
