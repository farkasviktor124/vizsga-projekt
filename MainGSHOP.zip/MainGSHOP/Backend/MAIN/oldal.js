function handleSearch() {
    var input = document.getElementById('searchInput');
    var filter = input.value.toUpperCase();
    var ul = document.getElementById("pillNav2");
    var li = ul.getElementsByTagName('li');
    for (var i = 0; i < li.length; i++) {
        var button = li[i].getElementsByTagName('button')[0];
        var txtValue = button.textContent || button.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}